from types import SimpleNamespace
import torch
from bench_perf import enable_peers, run_case
from workloads import CASES, Workload
args=SimpleNamespace(rounds=30,profile_rounds=3,check=True,check_only=False)
enable_peers([0,1])
with torch.inference_mode():
 for i,spec in enumerate((Workload("single_32768",(32768,),1),*CASES)):
  methods=("cp-fa2-default","cp") if i%2==0 else ("cp","cp-fa2-default")
  run_case(spec,methods,args,False)
