import os,shutil
from pathlib import Path
from torch.utils.cpp_extension import load
p=Path('DLSlime/csrc').resolve()
ops=p/'dlslime/ops/intra_ll/all_to_all'
src=[p/'python/bind.cpp',ops/'alltoall_buffer.cpp',ops/'all_to_all_intra_ll_buffer.cpp',ops/'all_to_all_intra_ll.cu']
dir=Path('slime_build'); dir.mkdir(exist_ok=True)
mod=load('_slime_c',[str(s) for s in src],build_directory=str(dir.resolve()),extra_include_paths=[str(p),str(p/'dlslime'),'/usr/local/cuda/include'],extra_cflags=['-std=c++20','-O2','-DBUILD_INTRA_OPS','-DTORCH_API_INCLUDE_EXTENSION_H'],extra_cuda_cflags=['-std=c++20','-O2','--expt-relaxed-constexpr','--extended-lambda','-DBUILD_INTRA_OPS'],verbose=True)
shutil.copy2(mod.__file__,'DLSlime/dlslime/_slime_c.so')
print('alltoall',mod.AllToAllBuffer.__name__,flush=True)
