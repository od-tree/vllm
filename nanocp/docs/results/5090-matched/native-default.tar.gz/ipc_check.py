import ctypes as c
import multiprocessing as mp
from pathlib import Path
class Handle(c.Structure):
    _fields_ = [('opaque', c.c_char * 64)]
def rank_main(rank, pipe):
    rt = c.CDLL('/usr/local/cuda/lib64/libcudart.so')
    rt.cudaGetErrorString.restype=c.c_char_p
    rt.cudaIpcOpenMemHandle.argtypes=[c.POINTER(c.c_void_p),Handle,c.c_uint]
    def ck(status):
        if status: raise RuntimeError(rt.cudaGetErrorString(status))
    ck(rt.cudaSetDevice(rank))
    ptr=c.c_void_p()
    ck(rt.cudaMalloc(c.byref(ptr),c.c_size_t(8192)))
    h=Handle()
    ck(rt.cudaIpcGetMemHandle(c.byref(h),ptr))
    pipe.send_bytes(bytes(h))
    remote=Handle.from_buffer_copy(pipe.recv_bytes())
    mapped=c.c_void_p()
    status=rt.cudaIpcOpenMemHandle(c.byref(mapped),remote,1)
    print(f'rank={rank} peer={1-rank} cudaIpcOpenMemHandle={status} {rt.cudaGetErrorString(status).decode()}',flush=True)
    pipe.send(status)
    pipe.recv()
    if not status: ck(rt.cudaIpcCloseMemHandle(mapped))
    ck(rt.cudaFree(ptr))
if __name__=='__main__':
    ctx=mp.get_context('spawn')
    pipes=ctx.Pipe()
    workers=[ctx.Process(target=rank_main,args=(r,pipes[r])) for r in (0,1)]
    for p in workers:p.start()
    for p in workers:p.join()
    assert all(p.exitcode==0 for p in workers)
