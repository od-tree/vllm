import os
from nanodeploy import LLM,SamplingParams
from nanodeploy.engine.sequence import Sequence
model=os.environ["Q"]+"/model"
engine=LLM(model,attention_tp=1,attention_dp=1,attention_sp=2,ffn_ep=2,ffn_tp=1,ffn_dp=1,sp_backend="nccl",kvcache_block_size=256,max_model_len=4096,max_num_batched_tokens=4096,max_num_seqs=8,dummy_weight=False,dummy_prefill=False,ray_address="local",master_address="127.0.0.1:29741")
seq=Sequence(engine.tokenizer.encode("The capital of France is"),sampling_params=SamplingParams(max_tokens=8))
engine.add_request([seq]);engine.generate();print(seq.completion_token_ids)
