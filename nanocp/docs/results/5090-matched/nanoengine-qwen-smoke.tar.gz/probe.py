import os,sys,torch
if sys.argv[1]=="fa":
 from flash_attn_interface import flash_attn_with_kvcache
 d="cuda"; q=torch.randn(1,1,32,128,device=d,dtype=torch.bfloat16); k=torch.randn(8,256,4,128,device=d,dtype=q.dtype); v=torch.randn_like(k)
 o=flash_attn_with_kvcache(q,k,v,cache_seqlens=torch.tensor([2048],dtype=torch.int32,device=d),page_table=torch.arange(8,device=d,dtype=torch.int32)[None],softmax_scale=128**-0.5,causal=False,return_softmax_lse=True)
 torch.cuda.synchronize();print(o[0].shape)
else:
 import torch.distributed as dist
 from nanodeploy.worker.sp_backend import create_sp_backend_factory
 r=int(os.environ["LOCAL_RANK"]);torch.cuda.set_device(r);dist.init_process_group("nccl",device_id=torch.device("cuda",r))
 f=create_sp_backend_factory(sys.argv[1]);b=f.create_buffer(rank=r,world_size=2,max_bs=1,max_dispatch_per_msg=2,buffer_size_bytes=2*4096*2);b.connect_full_mesh(dist.group.WORLD)
 b.local_buffer.zero_();x=torch.full((1,4096),1+r,dtype=torch.bfloat16,device=r);mask=torch.ones((2,1),dtype=torch.int32,device=r);mask[r]=0
 offsets=torch.tensor([0,int(r==1),1],dtype=torch.int32,device=r)
 out=b.all_to_all_ll(x,mask=mask,offsets=offsets);torch.cuda.synchronize();torch.testing.assert_close(out[0],torch.full_like(x[0],2-r),rtol=0,atol=0); print(r,"remote Q verified",flush=True);dist.destroy_process_group()
